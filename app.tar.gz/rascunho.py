from datetime import date



meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']
mes = date.today().strftime('%B')
year = date.today().strftime('%Y')

match mes:
    case "January":
        mes = "Janeiro"
    case "February":
        mes = "Fevereiro"
    case "March":
        mes = "Março"
    case "April":
        mes = "Abril"
    case "May":
        mes = "Maio"
    case "June":
        mes = "Junho"
    case "July":
        mes = "Julho"
    case "August":
        mes = "Agosto"
    case "September":
        mes = "Setembro"
    case "October":
        mes = "Outubro"
    case "November":
        mes = "Novembro"
    case "December":
        mes = "Dezembro"

        
    

print(f'{mes} de {year}')