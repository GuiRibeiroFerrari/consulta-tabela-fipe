import flet as ft
import requests
from datetime import date

mytoken = "4708|TIw51kJ7vqFWQHN8tpS01EAlajzClQo1"

def main(page:ft.Page):
    
    def selctCategoria(e):
        drop_marcas.options.clear()
        drop_modelo.options.clear()
        table.rows.clear()
        match drop_categoria.value:
            case "Carro":
                id_categoria = 1
            case "Moto":
                id_categoria = 2
            case "Caminhão":
                id_categoria = 3
        
        global request_marca
        request_marca = requests.get(f"https://api.invertexto.com/v1/fipe/brands/{id_categoria}?token={mytoken}")
        for marca in eval(request_marca.text):
          drop_marcas.options.append(ft.dropdown.Option(marca["brand"]))
          
        text_marca.value = ''
        text_modelo.value = ''
        
        page.update()

    def selctMarca(e):
        drop_modelo.options.clear()
        table.rows.clear()
        for marca in eval(request_marca.text):
            if drop_marcas.value == marca["brand"]:
                id_marca_selecionada = marca["id"]
                break
        global request_modelo
        request_modelo = requests.get(f"https://api.invertexto.com/v1/fipe/models/{id_marca_selecionada}?token={mytoken}")
        for modelo in eval(request_modelo.text):
            drop_modelo.options.append(ft.dropdown.Option(modelo["model"]))
        
        text_marca.value = f"{drop_marcas.value}"
        text_modelo.value = ''

        page.update()

    def selectModelo(e):
        #drop_ano.options.clear()
        for modelo in eval(request_modelo.text):
            if drop_modelo.value == modelo["model"]:
                fipe_code = modelo["fipe_code"]
                break
            
        request_ano = requests.get(f"https://api.invertexto.com/v1/fipe/years/{fipe_code}?token={mytoken}")
        request_ano_text = eval(request_ano.text)
        
        table.rows.clear()
        for ano in request_ano_text['years']:
            #drop_ano.options.append(ft.dropdown.Option(ano["model_year"]))
            
            table.rows.append(ft.DataRow(
                cells=[
                    ft.DataCell(ft.Text(f"{ano['fuel']}")),
                    ft.DataCell(ft.Text(f"{ano['model_year']}")),
                    ft.DataCell(ft.Text(f"{'R$ {:,.2f}'.format(ano['price'])}")),
                ]
            ))
            
            
        text_modelo.value = f"{drop_modelo.value}"
            
        page.update()

    def mes_atual_function():
        mes = date.today().strftime('%B')
        ano = date.today().strftime('%Y')

        match mes:
            case "January":
                mes = "Janeiro"
            case "February":
                mes = "Fevereiro"
            case "March":
                mes = "Março"
            case "April":
                mes = "Abril"
            case "May":
                mes = "Maio"
            case "June":
                mes = "Junho"
            case "July":
                mes = "Julho"
            case "August":
                mes = "Agosto"
            case "September":
                mes = "Setembro"
            case "October":
                mes = "Outubro"
            case "November":
                mes = "Novembro"
            case "December":
                mes = "Dezembro"
        
        return f"{mes} de {ano}"

    drop_categoria = ft.Dropdown(
                    width=300,
                    label="Tipo de Automovel",
                    hint_text="Carro, Caminhão, Moto",
                    options=[
                        ft.dropdown.Option("Carro"),
                        ft.dropdown.Option("Moto"),
                        ft.dropdown.Option("Caminhão"),
                    ],
                    on_change=selctCategoria
                )
    
    drop_marcas = ft.Dropdown(
                    width=300,
                    label="Marca",
                    hint_text="Marca do veiculo",
                    options=[],
                    on_change=selctMarca
                )
    
    drop_modelo = ft.Dropdown(
                    width=300,
                    label="Modelo",
                    hint_text="Modelo do veiculo",
                    options=[],
                    on_change=selectModelo
                )

    table = ft.DataTable(
            columns=[
                ft.DataColumn(ft.Text("Combustivel")),
                ft.DataColumn(ft.Text("Ano"), numeric=True),
                ft.DataColumn(ft.Text("Preço")),
            ],
            rows=[],
        )

    mes_atual = ft.Text(value=f"{mes_atual_function()}")
    
    text_label_marca = ft.Text(value=f"Marca:", size=20, weight=ft.FontWeight.W_600)
    text_marca = ft.Text(value=f"", size=14, weight=ft.FontWeight.W_300)
    
    text_label_modelo = ft.Text(value=f"Modelo:", size=20, weight=ft.FontWeight.W_600)
    text_modelo = ft.Text(value=f"", size=14, weight=ft.FontWeight.W_300)

    page.scroll = ft.ScrollMode.AUTO

    page.add(
        ft.Row(
            alignment=ft.MainAxisAlignment.CENTER,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                ft.Column(
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Row(height=50),
                        ft.Text(
                            value="Consulta Tabela FIPE",
                            size=28,
                            weight=ft.FontWeight.W_700,
                        ),
                        ft.Row(height=20),
                        drop_categoria,
                        drop_marcas,
                        drop_modelo,
                        ft.Row(height=50),
                        ft.Text(
                            value="Valores referente ao mês atual",
                            size=22,
                            weight=ft.FontWeight.W_700,
                        ),
                        mes_atual,
                        ft.Row(height=50),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                text_label_marca,
                                text_marca
                            ],
                        ),
                        ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                text_label_modelo,
                                text_modelo
                            ]
                        ),
                        ft.Row(height=30),
                        table
                    ]
                ),   
            ]
        )
    )

ft.app(target=main, assets_dir="assets")